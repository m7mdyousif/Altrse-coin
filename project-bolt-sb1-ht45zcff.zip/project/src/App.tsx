import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Statistics from './components/Statistics';
import Tokenomics from './components/Tokenomics';
import Roadmap from './components/Roadmap';
import SmartContract from './components/SmartContract';
import Whitepaper from './components/Whitepaper';
import FAQ from './components/FAQ';
import SocialLinks from './components/SocialLinks';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="bg-black text-white antialiased">
      <Navbar />
      <Hero />
      <About />
      <Statistics />
      <Tokenomics />
      <Roadmap />
      <SmartContract />
      <Whitepaper />
      <FAQ />
      <SocialLinks />
      <Footer />
    </div>
  );
}
