import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Statistics', href: '#statistics' },
  { label: 'Tokenomics', href: '#tokenomics' },
  { label: 'Roadmap', href: '#roadmap' },
  { label: 'Contract', href: '#contract' },
  { label: 'FAQ', href: '#faq' },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-black/90 backdrop-blur-xl border-b border-gold-500/10 shadow-lg shadow-black/50'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <a href="#" className="flex items-center gap-3 group">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-gold flex items-center justify-center shadow-gold">
              <span className="text-black font-bold text-sm sm:text-base">A</span>
            </div>
            <span className="font-display text-xl sm:text-2xl font-bold text-gradient-gold">
              ALTRSE
            </span>
          </a>

          <div className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm text-gray-300 hover:text-gold-400 transition-colors duration-300 rounded-lg hover:bg-gold-500/5"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#hero"
              className="ml-4 px-5 py-2.5 bg-gradient-gold text-black font-semibold text-sm rounded-lg hover:shadow-gold-lg transition-all duration-300 hover:scale-105"
            >
              Buy ALT
            </a>
          </div>

          <button
            className="md:hidden p-2 text-gray-300 hover:text-gold-400 transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden bg-black/95 backdrop-blur-xl border-b border-gold-500/10">
          <div className="px-4 py-4 space-y-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="block px-4 py-3 text-gray-300 hover:text-gold-400 hover:bg-gold-500/5 rounded-lg transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#hero"
              onClick={() => setMobileOpen(false)}
              className="block mt-4 px-5 py-3 bg-gradient-gold text-black font-semibold text-sm rounded-lg text-center"
            >
              Buy ALT
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
