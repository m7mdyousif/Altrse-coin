import { useState } from 'react';
import { useInView } from '../hooks/useAnimations';
import { ChevronDown } from 'lucide-react';

const FAQ_ITEMS = [
  {
    q: 'What is ALTRSE Coin (ALT)?',
    a: 'ALTRSE Coin is a community-driven cryptocurrency built on the Ethereum blockchain (ERC-20) focused on growth, innovation, and global adoption. It is designed to empower holders through decentralized governance and real-world utility.',
  },
  {
    q: 'How can I buy ALTRSE Coin?',
    a: 'You can purchase ALT through decentralized exchanges (DEXs) by connecting your wallet and swapping ETH or stablecoins for ALT. As we progress through our roadmap, ALT will also become available on centralized exchanges.',
  },
  {
    q: 'Is the smart contract audited?',
    a: 'Yes, the ALTRSE Coin smart contract has been fully audited by an independent security firm. The audit report is publicly available, and the contract source code is verified on Etherscan for full transparency.',
  },
  {
    q: 'What makes ALTRSE different from other tokens?',
    a: 'ALTRSE is uniquely community-driven with 50% of the total supply allocated to the community. Our focus on global adoption, strategic partnerships, and real-world utility sets us apart from purely speculative tokens.',
  },
  {
    q: 'How does the community governance work?',
    a: 'ALT holders can participate in governance by proposing and voting on key decisions that shape the project\'s direction. Each token represents voting power, ensuring that the community\'s voice drives development.',
  },
  {
    q: 'Where can I store my ALT tokens?',
    a: 'Since ALT is an ERC-20 token, it can be stored in any Ethereum-compatible wallet such as MetaMask, Trust Wallet, Ledger, or any hardware wallet that supports ERC-20 tokens.',
  },
  {
    q: 'What is the total supply of ALT?',
    a: 'The total supply of ALTRSE Coin is 1 billion tokens. The distribution is as follows: 50% Community, 20% Liquidity, 15% Marketing, 10% Development, and 5% Reserve.',
  },
];

function FAQItem({ q, a, isOpen, onToggle }: { q: string; a: string; isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="glass rounded-xl overflow-hidden transition-all duration-300 hover:shadow-gold">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-5 sm:p-6 text-left group"
      >
        <span className="text-sm sm:text-base font-medium text-white pr-4">{q}</span>
        <ChevronDown
          size={20}
          className={`text-gold-400 shrink-0 transition-transform duration-300 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-gray-400 leading-relaxed border-t border-gold-500/10 pt-4">
          {a}
        </div>
      </div>
    </div>
  );
}

export default function FAQ() {
  const { ref, isInView } = useInView();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div ref={ref} className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-12 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            Support
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-bold">
            Frequently Asked <span className="text-gradient-gold">Questions</span>
          </h2>
        </div>

        <div
          className={`space-y-3 transition-all duration-700 delay-200 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {FAQ_ITEMS.map((item, i) => (
            <FAQItem
              key={i}
              q={item.q}
              a={item.a}
              isOpen={openIndex === i}
              onToggle={() => setOpenIndex(openIndex === i ? null : i)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
