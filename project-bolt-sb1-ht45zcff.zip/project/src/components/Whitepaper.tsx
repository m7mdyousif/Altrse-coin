import { useInView } from '../hooks/useAnimations';
import { FileText, ArrowRight } from 'lucide-react';

export default function Whitepaper() {
  const { ref, isInView } = useInView();

  return (
    <section className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div
        ref={ref}
        className={`relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center transition-all duration-700 ${
          isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="glass rounded-2xl p-8 sm:p-12 md:p-16 shadow-gold relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-gold" />

          <div className="w-16 h-16 rounded-2xl bg-gold-500/10 flex items-center justify-center mx-auto mb-8">
            <FileText size={32} className="text-gold-400" />
          </div>

          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            Documentation
          </span>

          <h2 className="font-display text-3xl sm:text-5xl font-bold mb-6">
            <span className="text-gradient-gold">Whitepaper</span>
          </h2>

          <p className="text-gray-400 max-w-2xl mx-auto mb-8 text-base sm:text-lg leading-relaxed">
            Explore the technical architecture, economic model, and strategic vision behind
            ALTRSE Coin. Our whitepaper provides comprehensive details on token mechanics,
            governance structure, and the roadmap to decentralized financial innovation.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="group inline-flex items-center gap-2 px-8 py-4 bg-gradient-gold text-black font-semibold rounded-xl hover:shadow-gold-lg transition-all duration-300 hover:scale-105">
              Read Whitepaper
              <ArrowRight
                size={18}
                className="group-hover:translate-x-1 transition-transform"
              />
            </button>
            <button className="inline-flex items-center gap-2 px-8 py-4 glass glass-hover text-gold-400 font-semibold rounded-xl transition-all duration-300 hover:scale-105">
              Download PDF
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
