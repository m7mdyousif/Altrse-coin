import { useAnimatedCounter, useInView } from '../hooks/useAnimations';
import { TrendingUp, Users, DollarSign, Droplets } from 'lucide-react';

interface StatCardProps {
  icon: React.ElementType;
  label: string;
  value: number;
  prefix?: string;
  suffix?: string;
  delay: number;
  isInView: boolean;
}

function StatCard({ icon: Icon, label, value, prefix = '', suffix = '', delay, isInView }: StatCardProps) {
  const { count, ref } = useAnimatedCounter(value, 2000);

  return (
    <div
      ref={ref}
      className={`glass glass-hover rounded-2xl p-6 sm:p-8 text-center group hover:shadow-gold transition-all duration-700 ${
        isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
      style={{ transitionDelay: isInView ? `${delay}ms` : '0ms' }}
    >
      <div className="w-14 h-14 rounded-xl bg-gold-500/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-gold-500/20 transition-colors duration-300">
        <Icon size={28} className="text-gold-400" />
      </div>
      <div className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-gradient-gold mb-2">
        {prefix}{count.toLocaleString()}{suffix}
      </div>
      <div className="text-sm text-gray-400 font-medium">{label}</div>
    </div>
  );
}

export default function Statistics() {
  const { ref, isInView } = useInView();

  const stats = [
    { icon: TrendingUp, label: 'Total Supply', value: 1000000000, prefix: '', suffix: '' },
    { icon: Users, label: 'Holders', value: 24850, prefix: '', suffix: '+' },
    { icon: DollarSign, label: 'Market Cap', value: 12, prefix: '$', suffix: 'M' },
    { icon: Droplets, label: 'Liquidity', value: 2, prefix: '$', suffix: 'M' },
  ];

  return (
    <section id="statistics" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div className="absolute inset-0 opacity-[0.02]">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, #D4A017 1px, transparent 0)',
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            Live Data
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-bold">
            Network <span className="text-gradient-gold">Statistics</span>
          </h2>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {stats.map((stat, i) => (
            <StatCard
              key={stat.label}
              {...stat}
              delay={i * 100}
              isInView={isInView}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
