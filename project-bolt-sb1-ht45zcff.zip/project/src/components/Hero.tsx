import { ArrowRight, Wallet, ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-dark" />

      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold-500/5 rounded-full blur-[120px] animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gold-600/5 rounded-full blur-[100px] animate-float-delayed" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold-500/3 rounded-full blur-[150px]" />
      </div>

      <div className="absolute inset-0 opacity-[0.03]">
        <div
          className="w-full h-full"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, #D4A017 1px, transparent 0)',
            backgroundSize: '40px 40px',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8">
            <div className="w-2 h-2 rounded-full bg-gold-400 animate-pulse-gold" />
            <span className="text-sm text-gold-300 font-medium">Live on Blockchain</span>
          </div>
        </div>

        <div className="animate-fade-in-up animate-delay-100">
          <div className="mb-8 inline-block">
            <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-gradient-gold mx-auto shadow-gold-lg animate-glow flex items-center justify-center">
              <span className="text-black font-display font-bold text-4xl sm:text-5xl">A</span>
            </div>
          </div>
        </div>

        <h1 className="animate-fade-in-up animate-delay-200 font-display text-5xl sm:text-7xl lg:text-8xl font-bold mb-6 tracking-tight">
          <span className="text-gradient-gold">ALTRSE</span>{' '}
          <span className="text-white">Coin</span>
        </h1>

        <p className="animate-fade-in-up animate-delay-300 text-lg sm:text-xl lg:text-2xl text-gray-400 max-w-2xl mx-auto mb-4 font-light">
          The Future of Decentralized Finance
        </p>

        <p className="animate-fade-in-up animate-delay-400 text-sm sm:text-base text-gray-500 max-w-xl mx-auto mb-12">
          Community-driven. Innovation-focused. Globally adopted.
        </p>

        <div className="animate-fade-in-up animate-delay-500 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#about"
            className="group inline-flex items-center gap-2 px-8 py-4 bg-gradient-gold text-black font-semibold rounded-xl hover:shadow-gold-lg transition-all duration-300 hover:scale-105 text-base"
          >
            Buy Now
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </a>
          <button className="group inline-flex items-center gap-2 px-8 py-4 glass glass-hover text-gold-400 font-semibold rounded-xl transition-all duration-300 hover:scale-105 text-base">
            <Wallet size={18} />
            Connect Wallet
          </button>
        </div>

        <div className="animate-fade-in-up animate-delay-500 mt-16 flex items-center justify-center gap-8 text-xs text-gray-500">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
            Network Active
          </div>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-gold-400" />
            Contract Verified
          </div>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-400" />
            Liquidity Locked
          </div>
        </div>

        <a
          href="#about"
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-gold-500/50 hover:text-gold-400 transition-colors animate-bounce"
        >
          <ChevronDown size={28} />
        </a>
      </div>
    </section>
  );
}
