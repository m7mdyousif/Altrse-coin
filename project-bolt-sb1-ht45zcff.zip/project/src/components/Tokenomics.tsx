import { useInView } from '../hooks/useAnimations';

const ALLOCATIONS = [
  { label: 'Community', pct: 50, color: 'from-gold-300 to-gold-500' },
  { label: 'Liquidity', pct: 20, color: 'from-gold-500 to-gold-700' },
  { label: 'Marketing', pct: 15, color: 'from-amber-400 to-amber-600' },
  { label: 'Development', pct: 10, color: 'from-yellow-500 to-yellow-700' },
  { label: 'Reserve', pct: 5, color: 'from-orange-400 to-orange-600' },
];

export default function Tokenomics() {
  const { ref, isInView } = useInView();

  return (
    <section id="tokenomics" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            Distribution
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-bold">
            Token <span className="text-gradient-gold">Economics</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div
            className={`transition-all duration-700 delay-200 ${
              isInView ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
            }`}
          >
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 mx-auto">
              <svg viewBox="0 0 200 200" className="w-full h-full -rotate-90">
                <circle
                  cx="100"
                  cy="100"
                  r="80"
                  fill="none"
                  stroke="rgba(212,160,23,0.1)"
                  strokeWidth="30"
                />
                {ALLOCATIONS.reduce<{ elements: React.ReactNode[]; offset: number }>(
                  (acc, alloc, i) => {
                    const circumference = 2 * Math.PI * 80;
                    const segmentLength = (alloc.pct / 100) * circumference;
                    const gap = 3;
                    const el = (
                      <circle
                        key={alloc.label}
                        cx="100"
                        cy="100"
                        r="80"
                        fill="none"
                        stroke={`url(#goldGrad${i})`}
                        strokeWidth="30"
                        strokeDasharray={`${segmentLength - gap} ${circumference - segmentLength + gap}`}
                        strokeDashoffset={-acc.offset}
                        strokeLinecap="round"
                        className={`transition-all duration-1000 ${
                          isInView ? 'opacity-100' : 'opacity-0'
                        }`}
                        style={{ transitionDelay: `${i * 150}ms` }}
                      />
                    );
                    acc.elements.push(el);
                    acc.offset += segmentLength;
                    return acc;
                  },
                  { elements: [], offset: 0 }
                ).elements}
                <defs>
                  {ALLOCATIONS.map((alloc, i) => (
                    <linearGradient key={i} id={`goldGrad${i}`} x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor={alloc.color.split(' ')[0].replace('from-', '') === 'gold-300' ? '#FFDB4D' : alloc.color.split(' ')[0].replace('from-', '') === 'gold-500' ? '#D4A017' : alloc.color.split(' ')[0].replace('from-', '') === 'amber-400' ? '#FBBF24' : alloc.color.split(' ')[0].replace('from-', '') === 'yellow-500' ? '#EAB308' : '#FB923C'} />
                      <stop offset="100%" stopColor={alloc.color.split(' ')[1].replace('to-', '') === 'gold-500' ? '#D4A017' : alloc.color.split(' ')[1].replace('to-', '') === 'gold-700' ? '#9A7209' : alloc.color.split(' ')[1].replace('to-', '') === 'amber-600' ? '#D97706' : alloc.color.split(' ')[1].replace('to-', '') === 'yellow-700' ? '#CA8A04' : '#EA580C'} />
                    </linearGradient>
                  ))}
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-3xl sm:text-4xl font-display font-bold text-gradient-gold">1B</div>
                  <div className="text-xs text-gray-500 uppercase tracking-wider">Total Supply</div>
                </div>
              </div>
            </div>
          </div>

          <div
            className={`transition-all duration-700 delay-300 ${
              isInView ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
            }`}
          >
            <div className="space-y-4">
              {ALLOCATIONS.map((alloc, i) => (
                <div
                  key={alloc.label}
                  className={`group glass rounded-xl p-4 sm:p-5 hover:shadow-gold transition-all duration-500 ${
                    isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                  }`}
                  style={{ transitionDelay: isInView ? `${400 + i * 100}ms` : '0ms' }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm sm:text-base font-medium text-white">
                      {alloc.label}
                    </span>
                    <span className="text-sm sm:text-base font-bold text-gold-400">
                      {alloc.pct}%
                    </span>
                  </div>
                  <div className="h-2 bg-dark-300 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-gold rounded-full transition-all duration-1000 ease-out`}
                      style={{
                        width: isInView ? `${alloc.pct}%` : '0%',
                        transitionDelay: `${600 + i * 100}ms`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
