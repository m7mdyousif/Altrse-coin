import { useInView } from '../hooks/useAnimations';
import { Send, Twitter, Globe } from 'lucide-react';

const SOCIALS = [
  {
    icon: Send,
    label: 'Telegram',
    href: '#',
    desc: 'Join the community',
  },
  {
    icon: Twitter,
    label: 'X (Twitter)',
    href: '#',
    desc: 'Follow for updates',
  },
  {
    icon: Globe,
    label: 'Website',
    href: '#',
    desc: 'Learn more',
  },
];

export default function SocialLinks() {
  const { ref, isInView } = useInView();

  return (
    <section className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div ref={ref} className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-12 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            Connect
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-bold">
            Join the <span className="text-gradient-gold">Community</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {SOCIALS.map((social, i) => (
            <a
              key={social.label}
              href={social.href}
              className={`group glass glass-hover rounded-2xl p-8 text-center hover:shadow-gold transition-all duration-700 ${
                isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: isInView ? `${i * 100}ms` : '0ms' }}
            >
              <div className="w-14 h-14 rounded-xl bg-gold-500/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-gold-500/20 group-hover:scale-110 transition-all duration-300">
                <social.icon size={28} className="text-gold-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{social.label}</h3>
              <p className="text-sm text-gray-400">{social.desc}</p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
