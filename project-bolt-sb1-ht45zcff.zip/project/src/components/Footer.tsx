export default function Footer() {
  return (
    <footer className="relative py-12 overflow-hidden">
      <div className="absolute inset-0 bg-black" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-gold flex items-center justify-center">
              <span className="text-black font-bold text-xs">A</span>
            </div>
            <span className="font-display text-xl font-bold text-gradient-gold">ALTRSE</span>
          </div>

          <div className="flex items-center gap-6 text-sm text-gray-500">
            <a href="#about" className="hover:text-gold-400 transition-colors">About</a>
            <a href="#tokenomics" className="hover:text-gold-400 transition-colors">Tokenomics</a>
            <a href="#roadmap" className="hover:text-gold-400 transition-colors">Roadmap</a>
            <a href="#contract" className="hover:text-gold-400 transition-colors">Contract</a>
          </div>

          <div className="w-16 h-px bg-gold-500/20" />

          <p className="text-xs text-gray-600">
            &copy; {new Date().getFullYear()} ALTRSE Coin. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
