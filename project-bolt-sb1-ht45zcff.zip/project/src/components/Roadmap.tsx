import { useInView } from '../hooks/useAnimations';
import { Rocket, Users, Handshake, ArrowUpRight, Globe } from 'lucide-react';

const PHASES = [
  {
    phase: 1,
    icon: Rocket,
    title: 'Launch',
    items: ['Token deployment & audit', 'Website & branding launch', 'Initial liquidity pool', 'Community channels setup'],
  },
  {
    phase: 2,
    icon: Users,
    title: 'Community Building',
    items: ['Marketing campaign rollout', 'Ambassador program', 'Community governance launch', 'Social media expansion'],
  },
  {
    phase: 3,
    icon: Handshake,
    title: 'Partnerships',
    items: ['Strategic partnerships', 'DeFi integrations', 'Cross-chain bridge development', 'Staking platform launch'],
  },
  {
    phase: 4,
    icon: ArrowUpRight,
    title: 'Exchange Listings',
    items: ['Tier-2 CEX listings', 'Tier-1 CEX applications', 'DEX aggregators integration', 'Market making partnerships'],
  },
  {
    phase: 5,
    icon: Globe,
    title: 'Global Expansion',
    items: ['Real-world utility partnerships', 'Payment gateway integration', 'NFT ecosystem launch', 'Global ambassador network'],
  },
];

export default function Roadmap() {
  const { ref, isInView } = useInView();

  return (
    <section id="roadmap" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            Journey
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-bold">
            Project <span className="text-gradient-gold">Roadmap</span>
          </h2>
        </div>

        <div className="relative">
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-gold-500/20 via-gold-500/10 to-transparent" />

          <div className="space-y-8 lg:space-y-12">
            {PHASES.map((phase, i) => {
              const isLeft = i % 2 === 0;
              return (
                <div
                  key={phase.phase}
                  className={`relative flex flex-col lg:flex-row items-center gap-6 lg:gap-12 transition-all duration-700 ${
                    isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  }`}
                  style={{ transitionDelay: isInView ? `${i * 150}ms` : '0ms' }}
                >
                  <div
                    className={`flex-1 ${
                      isLeft ? 'lg:text-right lg:order-1' : 'lg:text-left lg:order-3'
                    }`}
                  >
                    <div className="glass glass-hover rounded-2xl p-6 sm:p-8 hover:shadow-gold transition-all duration-300">
                      <div
                        className={`flex items-center gap-3 mb-4 ${
                          isLeft ? 'lg:flex-row-reverse' : ''
                        }`}
                      >
                        <div className="w-10 h-10 rounded-lg bg-gold-500/10 flex items-center justify-center shrink-0">
                          <phase.icon size={20} className="text-gold-400" />
                        </div>
                        <div>
                          <div className="text-xs text-gold-400 font-semibold uppercase tracking-wider">
                            Phase {phase.phase}
                          </div>
                          <h3 className="text-lg font-semibold text-white">{phase.title}</h3>
                        </div>
                      </div>
                      <ul className={`space-y-2 ${isLeft ? 'lg:text-right' : 'lg:text-left'}`}>
                        {phase.items.map((item) => (
                          <li key={item} className="text-sm text-gray-400 flex items-center gap-2">
                            <div className="w-1 h-1 rounded-full bg-gold-500 shrink-0" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="hidden lg:flex items-center justify-center order-2 z-10">
                    <div className="w-12 h-12 rounded-full bg-gradient-gold flex items-center justify-center shadow-gold">
                      <span className="text-black font-bold text-sm">{phase.phase}</span>
                    </div>
                  </div>

                  <div className="flex-1 lg:order-3" />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
