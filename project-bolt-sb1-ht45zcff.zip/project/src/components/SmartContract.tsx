import { useInView, useCopyToClipboard } from '../hooks/useAnimations';
import { Copy, Check, ExternalLink } from 'lucide-react';

const CONTRACT_ADDRESS = '0x7a3d...e9f1A2b8C4d6E0F2a4B6c8D0E2f4A6b8C0d2E4f6';

export default function SmartContract() {
  const { ref, isInView } = useInView();
  const { copied, copy } = useCopyToClipboard();

  return (
    <section id="contract" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div ref={ref} className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-12 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            Verified
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-bold">
            Smart <span className="text-gradient-gold">Contract</span>
          </h2>
        </div>

        <div
          className={`glass rounded-2xl p-6 sm:p-10 shadow-gold transition-all duration-700 delay-200 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="flex items-center gap-2 mb-6">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm text-green-400 font-medium">Contract Verified</span>
          </div>

          <div className="bg-dark-300 rounded-xl p-4 sm:p-6 mb-6">
            <div className="flex items-center justify-between gap-4">
              <code className="text-gold-300 text-xs sm:text-sm break-all font-mono">
                {CONTRACT_ADDRESS}
              </code>
              <button
                onClick={() => copy(CONTRACT_ADDRESS)}
                className="shrink-0 p-2.5 rounded-lg bg-gold-500/10 hover:bg-gold-500/20 text-gold-400 transition-all duration-300 hover:scale-110"
              >
                {copied ? <Check size={18} /> : <Copy size={18} />}
              </button>
            </div>
          </div>

          {copied && (
            <div className="text-center text-sm text-green-400 mb-4 animate-fade-in">
              Address copied to clipboard!
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            <div className="glass rounded-xl p-4">
              <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">Network</div>
              <div className="text-sm text-white font-medium">Ethereum</div>
            </div>
            <div className="glass rounded-xl p-4">
              <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">Standard</div>
              <div className="text-sm text-white font-medium">ERC-20</div>
            </div>
            <div className="glass rounded-xl p-4">
              <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">Audited</div>
              <div className="text-sm text-green-400 font-medium">Yes</div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <a
              href="#"
              className="inline-flex items-center gap-2 text-sm text-gold-400 hover:text-gold-300 transition-colors"
            >
              View on Etherscan
              <ExternalLink size={14} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
