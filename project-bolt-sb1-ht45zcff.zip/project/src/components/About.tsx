import { useInView } from '../hooks/useAnimations';
import { Shield, Globe, Zap, Users } from 'lucide-react';

const FEATURES = [
  {
    icon: Users,
    title: 'Community Driven',
    description: 'Governed by its holders through decentralized voting and community proposals.',
  },
  {
    icon: Zap,
    title: 'Fast & Efficient',
    description: 'Lightning-fast transactions with minimal fees powered by cutting-edge blockchain technology.',
  },
  {
    icon: Shield,
    title: 'Secure & Transparent',
    description: 'Fully audited smart contract with open-source code and verifiable on-chain data.',
  },
  {
    icon: Globe,
    title: 'Global Adoption',
    description: 'Building partnerships and integrations worldwide to drive real-world utility.',
  },
];

export default function About() {
  const { ref, isInView } = useInView();

  return (
    <section id="about" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block text-gold-400 text-sm font-semibold tracking-widest uppercase mb-4">
            About ALT
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-bold mb-6">
            Built for the <span className="text-gradient-gold">Future</span>
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto text-base sm:text-lg leading-relaxed">
            ALTRSE Coin is a community-driven cryptocurrency focused on growth, innovation, and
            global adoption. We believe in the power of decentralization to transform financial
            systems and create opportunities for everyone, everywhere.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES.map((feature, i) => (
            <div
              key={feature.title}
              className={`group glass glass-hover rounded-2xl p-6 sm:p-8 transition-all duration-700 hover:shadow-gold ${
                isInView
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: isInView ? `${i * 100}ms` : '0ms' }}
            >
              <div className="w-12 h-12 rounded-xl bg-gold-500/10 flex items-center justify-center mb-5 group-hover:bg-gold-500/20 transition-colors duration-300">
                <feature.icon size={24} className="text-gold-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-3">{feature.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
